/**
 * api/update.js — one-click availability update
 * Called when a creative clicks a button in their ping email.
 * Validates the token, updates their row in Google Sheets, shows confirmation.
 *
 * Env vars required:
 *   UPDATE_SECRET       — same secret used to sign tokens in ping.js
 *   SHEETS_API_KEY      — Google Sheets API key (for writes)
 *   SHEETS_SPREADSHEET_ID — the spreadsheet ID (not the published URL)
 *   SITE_URL            — e.g. https://colophon.co
 */

const VALID_STATUSES = ['available', 'soon', 'booked', 'unsubscribe'];
const AVAIL_COL = 7;    // column index of availability in sheet (0-indexed)
const PINGED_COL = 16;  // column index of last_pinged in sheet

function decodeToken(token) {
  try {
    return JSON.parse(Buffer.from(token, 'base64url').toString());
  } catch { return null; }
}

function confirmationPage(status, name) {
  const messages = {
    available:   { h: 'you\'re on the bench.',      sub: 'we\'ve updated your status to available. clients can see you now.', dot: '#2a8a3a' },
    soon:        { h: 'noted.',                      sub: 'we\'ve updated your status to available in 2–4 weeks.', dot: '#c87c18' },
    booked:      { h: 'got it. enjoy the project.', sub: 'we\'ve removed you from the active bench. we\'ll check in again soon.', dot: '#b04040' },
    unsubscribe: { h: 'you\'re off the bench.',     sub: 'we\'ve removed you entirely. if you ever want back on, just email us.', dot: '#888580' },
  };
  const m = messages[status] || messages.available;
  return `<!DOCTYPE html><html><head><meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1"/>
<title>colophon — updated</title>
<style>*{margin:0;padding:0;box-sizing:border-box}body{background:#f4f1ec;min-height:100vh;display:flex;align-items:center;justify-content:center;font-family:'Courier New',monospace;padding:40px 20px}</style>
</head><body>
<div style="max-width:440px;text-align:center;">
  <div style="width:48px;height:48px;border-radius:50%;background:${m.dot};margin:0 auto 24px;"></div>
  <h1 style="font-family:Georgia,serif;font-weight:700;font-size:clamp(28px,5vw,44px);letter-spacing:-0.03em;line-height:0.95;color:#0d0d0b;margin-bottom:16px;">${m.h}</h1>
  <p style="font-size:11px;line-height:1.75;color:#888580;margin-bottom:32px;">${m.sub}</p>
  <p style="font-size:10px;color:#888580;letter-spacing:0.1em;">— colophon</p>
</div>
</body></html>`;
}

export default async function handler(req, res) {
  const { id, status, token } = req.query;

  // 1. Validate inputs
  if (!id || !status || !token) {
    return res.status(400).send('missing parameters');
  }
  if (!VALID_STATUSES.includes(status)) {
    return res.status(400).send('invalid status');
  }

  // 2. Validate token
  const payload = decodeToken(token);
  if (!payload) return res.status(401).send('invalid token');
  if (Date.now() > payload.exp) return res.status(401).send('token expired');
  if (String(payload.id) !== String(id)) return res.status(401).send('token mismatch');

  // 3. Update Google Sheet via Sheets API
  // Row index = id + 1 (header row is row 1)
  const rowNum = parseInt(id) + 1;
  const spreadsheetId = process.env.SHEETS_SPREADSHEET_ID;
  const apiKey = process.env.SHEETS_API_KEY;

  if (spreadsheetId && apiKey) {
    const statusMap = {
      available:   'Immediate (Ready to start within 1 week)',
      soon:        '2-4 Weeks Out',
      booked:      'Waitlist Only (Currently booked, but open to future discussions)',
      unsubscribe: 'REMOVED',
    };

    // Update availability column
    const availRange = `Sheet1!H${rowNum}`; // column H = index 7
    await fetch(
      `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/${availRange}?valueInputOption=RAW&key=${apiKey}`,
      {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ values: [[statusMap[status]]] }),
      }
    );

    // Update last_pinged column
    const pingRange = `Sheet1!Q${rowNum}`; // column Q = index 16
    await fetch(
      `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/${pingRange}?valueInputOption=RAW&key=${apiKey}`,
      {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ values: [[new Date().toISOString()]] }),
      }
    );
  }

  // 4. Return confirmation page
  const name = req.query.name || 'creative';
  return res.status(200).send(confirmationPage(status, name));
}
