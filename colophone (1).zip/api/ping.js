/**
 * api/ping.js — Colophon availability ping
 * Runs every 20 days via Vercel cron.
 * Reads creative bench from Google Sheets, sends ping email to everyone
 * whose last_pinged date is > 20 days ago (or never).
 *
 * Env vars required:
 *   RESEND_API_KEY      — from resend.com
 *   SHEETS_CSV_URL      — published Google Sheets CSV URL (bench tab)
 *   UPDATE_SECRET       — random string used to sign one-click update tokens
 *   SITE_URL            — e.g. https://colophon.co
 */

const RESEND_API_KEY = process.env.RESEND_API_KEY;
const SHEETS_CSV_URL = process.env.SHEETS_CSV_URL;
const UPDATE_SECRET  = process.env.UPDATE_SECRET;
const SITE_URL       = process.env.SITE_URL || 'https://colophon.co';
const FROM_EMAIL     = 'bench@colophon.co';
const PING_INTERVAL_DAYS = 20;

// ── Token helpers ──────────────────────────────────────────────────────────────
// Simple HMAC-lite: base64(JSON + secret hash). Good enough for one-click links.
// In production swap for crypto.createHmac('sha256', secret).
function makeUpdateToken(id, status) {
  const payload = { id, status, exp: Date.now() + 7 * 86400000 }; // expires in 7 days
  return Buffer.from(JSON.stringify(payload)).toString('base64url');
}

// ── CSV parser ────────────────────────────────────────────────────────────────
function parseCSV(text) {
  const lines = text.split('\n').filter(l => l.trim());
  const parseRow = row => {
    const f = []; let cur = '', inQ = false;
    for (const c of row) {
      if (c === '"') inQ = !inQ;
      else if (c === ',' && !inQ) { f.push(cur.trim()); cur = ''; }
      else cur += c;
    }
    f.push(cur.trim());
    return f;
  };
  return lines.slice(1).map((line, i) => {
    const row = parseRow(line);
    return {
      id:           i + 1,
      name:         row[1] || '',
      email:        row[2] || '',
      availability: row[7] || '',
      lastPinged:   row[16] || '', // add a "Last Pinged" column to your sheet
    };
  }).filter(r => r.email && r.email.includes('@'));
}

// ── Email builder ─────────────────────────────────────────────────────────────
function buildEmail(creative) {
  const firstName = creative.name.split(' ')[0].toLowerCase();
  const philName  = `${firstName}`; // use real first name in email (not philosopher)

  const dot = (status, color) =>
    `<span style="display:inline-block;width:8px;height:8px;border-radius:50%;background:${color};margin-right:10px;vertical-align:middle;"></span>`;

  const btn = (status, label, color, bg, border, textColor) => {
    const token = makeUpdateToken(creative.id, status);
    const url   = `${SITE_URL}/api/update?id=${creative.id}&status=${status}&token=${token}`;
    return `
      <tr><td style="padding-bottom:10px;">
        <a href="${url}" style="display:block;padding:16px 24px;font-family:'Courier New',monospace;font-size:11px;letter-spacing:0.08em;color:${textColor};text-decoration:none;background:${bg};border:1px solid ${border};">
          ${dot(status, color)}${label}<span style="float:right;opacity:0.4;">→</span>
        </a>
      </td></tr>`;
  };

  const unsubToken = makeUpdateToken(creative.id, 'unsubscribe');

  return {
    from: `colophon <${FROM_EMAIL}>`,
    to:   creative.email,
    subject: `still on the bench, ${philName}?`,
    html: `<!DOCTYPE html><html><head><meta charset="UTF-8"/></head><body style="background:#e8e5de;margin:0;padding:40px 20px;font-family:'Courier New',monospace;">
<table width="100%" cellpadding="0" cellspacing="0" style="max-width:560px;margin:0 auto;background:#f4f1ec;border:1px solid rgba(13,13,11,0.12);">
  <tr><td style="padding:28px 40px 24px;border-bottom:1px solid rgba(13,13,11,0.1);">
    <span style="font-family:Georgia,serif;font-weight:700;font-size:16px;color:#0d0d0b;">colo<span style="color:#ff5100;">phon</span></span>
  </td></tr>
  <tr><td style="padding:44px 40px 0;">
    <p style="font-size:10px;letter-spacing:0.14em;color:#888580;margin-bottom:24px;">availability check — 20 days</p>
    <h1 style="font-family:Georgia,serif;font-weight:700;font-size:34px;line-height:0.95;letter-spacing:-0.03em;color:#0d0d0b;margin-bottom:24px;">
      still on the bench,<br/><span style="color:#ff5100;">${philName}?</span>
    </h1>
    <p style="font-size:12px;line-height:1.75;color:#888580;margin-bottom:8px;">it's been 20 days. one tap is all we need.</p>
    <p style="font-size:12px;line-height:1.75;color:#888580;margin-bottom:36px;">your status right now: <span style="color:#2a8a3a;">● ${creative.availability.toLowerCase().includes('immediate') ? 'available' : creative.availability.toLowerCase().includes('waitlist') ? 'waitlisted' : 'available in 2–4 weeks'}</span></p>
    <table width="100%" cellpadding="0" cellspacing="0" style="margin-bottom:40px;">
      ${btn('available', 'still available — keep me on the bench', '#2a8a3a', '#0d0d0b', '#0d0d0b', '#f4f1ec')}
      ${btn('soon',      'available in 2–4 weeks',                 '#c87c18', '#f4f1ec', 'rgba(13,13,11,0.12)', '#0d0d0b')}
      ${btn('booked',    'fully booked — remove me for now',        '#b04040', '#f4f1ec', 'rgba(13,13,11,0.12)', '#0d0d0b')}
    </table>
    <hr style="border:none;border-top:1px solid rgba(13,13,11,0.1);margin-bottom:28px;"/>
    <p style="font-size:10px;line-height:1.75;color:#888580;margin-bottom:8px;">one tap. no login, no form.<br/>we send this every 20 days to keep the bench current.</p>
    <p style="font-size:10px;line-height:1.75;color:#888580;margin-bottom:32px;">to update your rates or portfolio link, reply to this email.</p>
  </td></tr>
  <tr><td style="padding:24px 40px 28px;border-top:1px solid rgba(13,13,11,0.1);">
    <table width="100%"><tr>
      <td><span style="font-family:Georgia,serif;font-weight:700;font-size:13px;color:#0d0d0b;">colo<span style="color:#ff5100;">phon</span></span>
        <span style="font-size:10px;color:#888580;margin-left:10px;">the bench is private. the work is public.</span></td>
      <td style="text-align:right;"><a href="${SITE_URL}/api/update?id=${creative.id}&status=unsubscribe&token=${unsubToken}" style="font-size:10px;color:#888580;text-decoration:none;">leave the bench →</a></td>
    </tr></table>
  </td></tr>
</table></body></html>`,
  };
}

// ── Handler ───────────────────────────────────────────────────────────────────
export default async function handler(req, res) {
  // Only allow cron calls (Vercel sets this header on cron jobs)
  if (req.headers['authorization'] !== `Bearer ${process.env.CRON_SECRET}`) {
    return res.status(401).json({ error: 'unauthorized' });
  }

  try {
    // 1. Fetch bench from Google Sheets
    const sheetRes = await fetch(SHEETS_CSV_URL);
    const csv = await sheetRes.text();
    const creatives = parseCSV(csv);

    // 2. Filter: only ping those not pinged in 20+ days
    const cutoff = Date.now() - PING_INTERVAL_DAYS * 86400000;
    const toEmail = creatives.filter(c => {
      if (!c.lastPinged) return true; // never pinged
      return new Date(c.lastPinged).getTime() < cutoff;
    });

    // 3. Send emails via Resend
    const results = [];
    for (const creative of toEmail) {
      const email = buildEmail(creative);
      const r = await fetch('https://api.resend.com/emails', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${RESEND_API_KEY}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(email),
      });
      const data = await r.json();
      results.push({ email: creative.email, status: r.status, id: data.id });
    }

    return res.status(200).json({
      sent: results.length,
      skipped: creatives.length - results.length,
      results,
    });

  } catch (err) {
    console.error('ping error:', err);
    return res.status(500).json({ error: err.message });
  }
}
