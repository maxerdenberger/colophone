/**
 * api/apply.js — handle "yes" click on a creative referral email
 * Validates the invite token, then 302-redirects to /apply with referrer pre-filled.
 *
 * Env: SITE_URL
 */

const SITE_URL = process.env.SITE_URL || 'https://colophon.co';

function decodeToken(token) {
  try { return JSON.parse(Buffer.from(token, 'base64url').toString()); }
  catch { return null; }
}

export default async function handler(req, res) {
  const { token, ref } = req.query;
  if (!token) return res.status(400).send('missing token');

  const payload = decodeToken(token);
  if (!payload)                        return res.status(401).send('invalid token');
  if (Date.now() > payload.exp)        return res.status(401).send('invitation expired');
  if (payload.type !== 'creative')     return res.status(401).send('wrong invite type');

  const url = `${SITE_URL}/apply?ref=${encodeURIComponent(ref || '')}&email=${encodeURIComponent(payload.email)}&via=referral`;
  res.writeHead(302, { Location: url });
  res.end();
}
