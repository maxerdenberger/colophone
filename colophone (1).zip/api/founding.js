/**
 * api/founding.js — handle "claim my free day" click from a buyer invite
 * Validates the invite token, generates a 24-hour access token,
 * and redirects to /access with it in the URL.
 *
 * No Stripe charge. No coupon. Just one free day on the bench.
 *
 * Env: SITE_URL
 */

const SITE_URL = process.env.SITE_URL || 'https://colophon.co';

function decodeInvite(token) {
  try { return JSON.parse(Buffer.from(token, 'base64url').toString()); }
  catch { return null; }
}

function makeAccessToken(email) {
  const payload = {
    exp:   Date.now() + 86400000,  // 24 hours
    tier:  'day',
    email,
    via:   'founding',
  };
  return Buffer.from(JSON.stringify(payload)).toString('base64url');
}

export default async function handler(req, res) {
  const { token } = req.query;
  if (!token) return res.status(400).send('missing token');

  const invite = decodeInvite(token);
  if (!invite)                       return res.status(401).send('invalid token');
  if (Date.now() > invite.exp)       return res.status(401).send('invitation expired');
  if (invite.type !== 'buyer')       return res.status(401).send('wrong invite type');

  const accessToken = makeAccessToken(invite.email);
  res.writeHead(302, { Location: `${SITE_URL}/access?t=${accessToken}` });
  res.end();
}
