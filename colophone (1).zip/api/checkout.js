/**
 * api/checkout.js — Dynamic Stripe Checkout for the bench builder
 *
 * Body: {
 *   amount:    number,             // dollars (will be * 100 for cents)
 *   duration:  'day' | 'week' | 'month',
 *   filters:   object,             // for analytics in metadata
 *   matched:   number,             // bench size after filters
 *   email:     string (optional)
 * }
 *
 * Returns: { url } — the Stripe Checkout URL to redirect to.
 *
 * Env: STRIPE_SECRET_KEY, SITE_URL
 */

const SITE_URL = process.env.SITE_URL || 'https://colophon.co';

const PASS_HOURS = { day: 24, week: 24 * 7, month: 24 * 30 };

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'POST only' });

  const { amount, duration, filters = {}, matched = 0, email } = req.body || {};

  if (typeof amount !== 'number' || amount < 29) {
    return res.status(400).json({ error: 'amount must be a number >= 29' });
  }
  if (!['day', 'week', 'month'].includes(duration)) {
    return res.status(400).json({ error: 'invalid duration' });
  }

  const cents = Math.round(amount * 100);
  const filterSummary = Object.entries(filters)
    .filter(([, v]) => Array.isArray(v) && v.length)
    .map(([k, v]) => `${k}: ${v.join(', ')}`)
    .join(' · ') || 'no filters';

  const params = new URLSearchParams({
    'mode':                                              'payment',
    'line_items[0][price_data][currency]':               'usd',
    'line_items[0][price_data][product_data][name]':     `colophon ${duration} pass`,
    'line_items[0][price_data][product_data][description]': `${matched} creatives · ${filterSummary}`,
    'line_items[0][price_data][unit_amount]':            String(cents),
    'line_items[0][quantity]':                           '1',
    'success_url':  `${SITE_URL}/access?session_id={CHECKOUT_SESSION_ID}&tier=${duration}`,
    'cancel_url':   `${SITE_URL}/?cancelled=1`,
    'metadata[duration]': duration,
    'metadata[matched]':  String(matched),
    'metadata[filters]':  filterSummary.slice(0, 480),
  });
  if (email) params.append('customer_email', email);

  try {
    const r = await fetch('https://api.stripe.com/v1/checkout/sessions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${process.env.STRIPE_SECRET_KEY}`,
        'Content-Type':  'application/x-www-form-urlencoded',
      },
      body: params.toString(),
    });
    const session = await r.json();
    if (!r.ok) return res.status(r.status).json({ error: session.error?.message || 'stripe error' });

    return res.status(200).json({ url: session.url });
  } catch (err) {
    return res.status(500).json({ error: err.message });
  }
}
